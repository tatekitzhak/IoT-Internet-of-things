import os
import sys
import csv
import time

LOG_TRAGET_PROMPT = 1
LOG_TRAGET_CORONYS = 2
LOG_TRAGET_BOTH = 3

try:
    import xlrd
    import xlsxwriter
except:
    self.install("xlrd")
    self.install("xlsxwriter")
    import xlrd
    import xlsxwriter
        
def install(self,package):
    '''
    @summary: function that installs packages using pip
    '''
    pip.main(['install', package])



class LoggerClass(object):
    LOGLEVEL_DEBUG   = 2
    LOGLEVEL_INFO    = 3
    LOGLEVEL_WARNING = 4
    LOGLEVEL_ERROR   = 5
    LOGLEVEL_EXCEPT  = 6
    def __init__(self, Level=LOGLEVEL_INFO,Target=LOG_TRAGET_PROMPT):
        self.__Log_Level = Level
        self.LOGTOFILE = False
        self.logger_target = Target
        
    def PrintLog(self, prtstring, Level = LOGLEVEL_INFO):
        if((self.logger_target == LOG_TRAGET_PROMPT) or (self.logger_target == LOG_TRAGET_BOTH)):
            if Level >= self.__Log_Level :
                print ("%s: %s" % (time.ctime(), str(prtstring)))
        if Level == self.LOGLEVEL_EXCEPT:
            raise Exception (prtstring)

class CsvHelpersClass():
    def __init__(self):
        pass
    
    @staticmethod
    def getDataFromCsv(csvFilename):
        data = list()
        reader = csv.DictReader(open(csvFilename))
        for row in reader:
            data.append(row)
            
        return data
    
    @staticmethod
    def setDataToCsv(csvFilename, headers, inputData):        
        with open(csvFilename, "wt") as output:            
            writer = csv.DictWriter(output, delimiter=',', lineterminator='\n', fieldnames=headers)
            writer.writeheader()
            for row in inputData:
                writer.writerow(row)
                
    @staticmethod
    def getHeaders(csvFilename): 
        reader = csv.DictReader(open(csvFilename))
        return reader.fieldnames

    @staticmethod
    def create_csv(MES_RES,Reference_Path):
        print('writing results..')
        Tools.DebugTools.WriteLUTtoFile (Reference_Path, MES_RES)        
        if not os.path.isfile(Reference_Path):
            raise TCD.Utilities.UserException(  "   CH_EMUL -> Failed while attempting to create a Reference file [![![!]")
        print('writing results - done!')

class ExcelHelpersClass:
    logger = LoggerClass()
    
    def __init__(self, logger = LoggerClass()):
        self.logger = logger
                
    @staticmethod
    def LoadExcelToLUT(InputFile, ExcelLUT=[], SheetName=''):
        print ("Reading Excel File: "+InputFile)
        wb = xlrd.open_workbook(InputFile)    
        s = wb.sheet_by_name(SheetName)
        print ("Sheet  found. Opening.")
        # Check if this is the requested Sheet
        if s.name == SheetName:    
            for row in range(0, s.nrows):
                row_list = [str(s.cell(row, col_index).value) for col_index in range(s.ncols)]
                ExcelLUT.append(row_list)        
        if ExcelLUT == []:
            print("Could not find any information in the excel.")

    @staticmethod
    def XLS_Handle(File_name,MES_RES,num_steps_per_Measure,Measurelist,Graph_name):
        
        workbook =  xlsxwriter.Workbook(File_name+ ".xlsx", {'constant_memory': True, 'strings_to_numbers': True,'nan_inf_to_errors':True})
        WorkSheetData = workbook.add_worksheet('Data')
        row_counter=0
        
        for k in MES_RES:
            if row_counter==0:
                WorkSheetData.write_row('A1',k)
            else:
                WorkSheetData.write_row(row_counter,0,k)
            row_counter=row_counter+1
        
        starting_index = 1
        
        for m in range(0,len(Measurelist)):    
            if m == 0:   
                RReportChart = workbook.add_chart({'type': 'scatter'})
                RReportChart.set_title({'name' : 'TEMP_CURVES '+str(Graph_name), 'Bold' : False}) 
                RReportChart.set_x_axis({'name' : 'Samples'})
                RReportChart.set_y_axis({'name' : 'Degrees [C]'})
                RReportChart.set_size({'width': 1200, 'height': 600}) 
                SheetChart  = workbook.add_chartsheet("DTH")
                    
            RReportChart.add_series({'values':     ['Data',starting_index,\
                                                        MES_RES[0].index("Humidity,%"),\
                                                        starting_index + num_steps_per_Measure[m]-1,\
                                                        MES_RES[0].index("Humidity,%")],\
                                                    'categories': ['Data',starting_index,\
                                                        MES_RES[0].index("Number of measurement"),\
                                                        starting_index + num_steps_per_Measure[m]-1,\
                                                        MES_RES[0].index("Number of measurement")],\
                                     'name' : "Measure : "+str(Measurelist[m])})
           
            starting_index = starting_index+num_steps_per_Measure[m]
        
        SheetChart.set_chart(RReportChart)

    
def main():
    # init object of ExcelHelpersClass
    Tools = ExcelHelpersClass    
    InputFile = 'C:\\Users\\c_yuryy\\Dropbox\\Carlos\\Excels\\Data_for_Neural_Net_Tune.xlsm'
    ExcelLUT = []
    SheetName = 'Maps'
#   Tools.LoadExcelToLUT(InputFile, ExcelLUT, SheetName)
    print('rr')
    
    
    File_name = 'C:\\Users\\c_yuryy\\Dropbox\\Tune'
    num_steps_per_Measure=[10]
    Measurelist=['777']
    Graph_name='Curve'
    
    MES_RES=[]
    MES_RES.append(['Number of measurement','Temperature,C','Humidity,%'])
    for i in range(num_steps_per_Measure[0]): 
        MES_RES.append([str(i+1),'27','60'])    
    Tools.XLS_Handle(File_name,MES_RES,num_steps_per_Measure,Measurelist,Graph_name)
    
    
    
    
if __name__ == "__main__":
    print('Starting main')
    main()    
    